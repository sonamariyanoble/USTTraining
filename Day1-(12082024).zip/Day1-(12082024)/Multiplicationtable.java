package Assignment;

public class Multiplicationtable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	for (int i =1;i<=10;i++) {
		for (int j=1;j<=10;j++) {
			int result = i * j;
			System.out.println(i+"*"+j+"="+result);
		}
	}
	}

}
