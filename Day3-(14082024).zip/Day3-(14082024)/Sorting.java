package Assignment;

public class Sorting {
 public static void main (String[] args) {
	 int pincome []= {82,53,-2,31,26,11};
	 System.out.println("Array before sorting...");
	 for (int i=0;i<pincome.length;i++) {
	 System.out.print(pincome[i]);
	 }
	 
	 int[] rincome= sort(pincome);
	 System.out.println("Array after sorting...");
	 for (int i=0;i<rincome.length;i++) {
	 System.out.print(rincome[i]);
	 }
	 }
 
 static int[] sort(int[] avalues) {
	 for(int i=0;i<avalues.length;i++) {
		 for(int j=0;j<avalues.length-i-1;j++) {
			 if(avalues[j]>avalues[i]) {
				 int temp= avalues[j];
				 avalues[j]=avalues[j+1];
				 avalues[j+1]=temp;
			 }
			 
		 }
	 }
	return avalues;
	 
 }
}
