package Assignment;

public class ArrayDiagonalSum {
	public static void main(String[] args) {
	    int[][] array = {
	      {9, 1, 8, 12},
	      {43, 18, 12, 74},
	      {86, 136, 19, 10},
	      {13, 12, 156, 164}
	    };

	    int primaryDiagonalSum = 0;
	    int secondaryDiagonalSum = 0;

	    for (int i = 0; i < array.length; i++) {
	      primaryDiagonalSum += array[i][i];
	      secondaryDiagonalSum += array[i][array.length - i - 1];
	    }

	    System.out.println("Primary Diagonal Sum: " + primaryDiagonalSum);
	    System.out.println("Secondary Diagonal Sum: " + secondaryDiagonalSum);
	  }


}
