package com.example.demo_rest;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/tkt")
public class DemoRestController {

	public DemoRestController() {
		System.out.println("Constructor DemoContrller()");
	}
	
	@GetMapping("/hello")
	String DemoRestController() {
		System.out.println("-----completed-----");
     return ("Hello World :)");
	}
	
	@GetMapping("/ticket")
	//localhost:8182/ticket?tid=878
	Ticket getuser(@RequestParam ("tid")int ticket) {
		System.out.println("-----Ticket Details-----");
     return new Ticket (ticket,"Sona","TVM",3);
	}
	
	
	//@RequestBody will create java object from the ticket
	@PostMapping("/book")
	Ticket bookTicket(@RequestBody Ticket ticket) {
		System.out.println("---Book Ticket");
		System.out.println("Booking Ticket"+ticket);
		ticket.setId(100);
		return ticket;
	}
	
	@DeleteMapping("/cancel")
	//localhost:8182/cancel?tid=8789
	String cancelTicket(@RequestParam ("tid") int ticketid) {
		System.out.println("-----Ticket cancelled----");
		return "Ticket with id " +ticketid+" is cancelled";
		
	}

}
