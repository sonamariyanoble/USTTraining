package com.example.demo_rest;

import org.springframework.stereotype.Component;

@Component
public class Ticket {

	private int id;
	private String name;
	private String address;
	private int num_of_seats;
	
	public Ticket() {
		// TODO Auto-generated constructor stub
	}

	public Ticket(int id, String name, String address,int num_of_seats) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.num_of_seats = num_of_seats;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getNum_of_seats() {
		return num_of_seats;
	}

	public void setNum_of_seats(int num_of_seats) {
		this.num_of_seats = num_of_seats;
	}
	

}
