package com.seleniumEg;

import java.io.File;
import java.time.Duration;
import org.openqa.selenium.io.FileHandler;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ScreenshotEg {
	public static void main(String[] args) throws Exception {
		 // chrome driver path
	    System.setProperty("Webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win64");
	    
	    //Create the instance of driver
	    WebDriver driver = new ChromeDriver();
	    
	    //Load the web page under test
	    driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.seleniumEg\\src\\main\\resources\\ScreenshotEg.html");
	    File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileHandler.copy(screenshot, new File("./screenshot1.png"));

		Thread.sleep(3000);
		driver.quit();
	    }
}
