package com.seleniumEg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByCSSEg3 {
public static void main(String[] args) throws Exception {
	 // chrome driver path
    System.setProperty("Webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win64");
    
    //Create the instance of driver
    WebDriver driver = new ChromeDriver();
    
    //Load the web page under test
    driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.seleniumEg\\src\\main\\resources\\LocateByCSSEg2.html");
    //css selector by attribute
    //No such element exception as for id need to use # instead of .
    //WebElement element =driver.findElement(By.cssSelector(".some-id"));
    //WebElement element =driver.findElement(By.cssSelector("#some-id"));   //this works
    //WebElement element =driver.findElement(By.cssSelector("input#some-id")); //this works
  //css selector by attribute --input[type='password']
    //WebElement element =driver.findElement(By.cssSelector("input[type='password']")); //this works
    
    //CSS Selector using parent child element
    //WebElement element =driver.findElement(By.cssSelector("form input); //this works
    WebElement element1 =driver.findElement(By.cssSelector("form input[type='text']"));
    WebElement element2 =driver.findElement(By.cssSelector("form input[type='password']"));
    element1.sendKeys("some user");
    element2.sendKeys("some password");
    Thread.sleep(2000);
    System.out.println(element1.getAttribute("value")+" & "+element2.getAttribute("value"));
    driver.quit();
}
}
