package com.seleniumEg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByNameEg {
public static void main(String[] args) throws Exception {
	 // chrome driver path
    System.setProperty("Webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win64");
    
    //Create the instance of driver
    WebDriver driver = new ChromeDriver();
    
    //Load the web page under test
    driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.seleniumEg\\src\\main\\resources\\LocateByNameEg.html");
    
    WebElement usernameField = driver.findElement(By.name("username"));
    usernameField.sendKeys("newusername");
    Thread.sleep(2000);
    driver.quit();
}
}
