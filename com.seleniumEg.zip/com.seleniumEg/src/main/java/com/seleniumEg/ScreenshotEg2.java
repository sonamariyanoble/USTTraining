package com.seleniumEg;

import java.io.File;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.io.FileHandler;

public class ScreenshotEg2 {
	public static void main(String[] args) throws Exception {
		 // chrome driver path
	    System.setProperty("Webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win64");
	    
	    //Create the instance of driver
	    WebDriver driver = new ChromeDriver();
	    
	    
	    //Load the web page under test
	    driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.seleniumEg\\src\\main\\resources\\LocateByLinkTextEg.html");
	    WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(35));
	    WebElement link1 = driver.findElement(By.linkText("Visit Expamle"));
	    File screenshot1 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileHandler.copy(screenshot1, new File("./screenshot1.png"));
	    link1.click();
	    
	    System.out.println("Title : "+driver.getTitle());
	    File screenshot2 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileHandler.copy(screenshot2, new File("./screenshot2.png"));
	    WebElement infolink =driver.findElement(By.partialLinkText("information"));
	    File screenshot3 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileHandler.copy(screenshot3, new File("./screenshot3.png"));
	    infolink.click();
	    Thread.sleep(3000);
	    
	    System.out.println("Next Page Title : "+driver.getTitle());
	    
	    
	    
	    Thread.sleep(1000);
	    driver.quit();
}
}
