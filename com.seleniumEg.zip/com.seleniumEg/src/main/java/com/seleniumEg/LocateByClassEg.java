package com.seleniumEg;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LocateByClassEg {
public static void main(String[] args) throws Exception {
	 // chrome driver path
    System.setProperty("Webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win64");
    
    //Create the instance of driver
    WebDriver driver = new ChromeDriver();
    
    //Load the web page under test
    driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.seleniumEg\\src\\main\\resources\\LocateByClassEg.html");
    
    WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(35));
    WebElement buttonField =wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("button")));
    buttonField.click();
    WebElement message =wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("message")));
    System.out.println("Message : "+message.getText());
    Thread.sleep(2000);
    driver.quit();
}
}
