package com.seleniumEg;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LocateByNameEg2 {
public static void main(String[] args) throws Exception {
	 // chrome driver path
    System.setProperty("Webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win64");
    
    //Create the instance of driver
    WebDriver driver = new ChromeDriver();
    
    //Load the web page under test
    driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.seleniumEg\\src\\main\\resources\\LocateByNameEg2.html");
    
    //wait until webpage loaded successfully
    //create web driver wait
    WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
    
    //locate username ,only after it appears on webpage
    WebElement usernameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")));
    
    //enter text in the username field
    usernameField.sendKeys("someuser");
    
    //locate age
    WebElement ageField = driver.findElement(By.name("age"));
    
    //eneter age value
    ageField.sendKeys(String.valueOf(35));
    
    //set country
    WebElement countryDropdown = driver.findElement(By.name("country"));
    countryDropdown.sendKeys("Canada");
    
    //locate button
    WebElement SubmitButton = driver.findElement(By.id("submitButton"));
    
    //click button
    SubmitButton.click();
    
    //wait for the message
    //Thread.sleep(2000);
    
    //get the updated message text
    
    //WebElement messageDiv = driver.findElement(By.id("message"));
    WebElement messageDiv = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("message")));
    System.out.println("Message Updated : "+messageDiv.getText());
    
    Thread.sleep(1000); 
    driver.quit();
}
}
