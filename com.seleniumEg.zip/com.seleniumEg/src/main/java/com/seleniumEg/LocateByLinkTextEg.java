package com.seleniumEg;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LocateByLinkTextEg {
	public static void main(String[] args) throws Exception {
		 // chrome driver path
	    System.setProperty("Webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win64");
	    
	    //Create the instance of driver
	    WebDriver driver = new ChromeDriver();
	    
	    //Load the web page under test
	    driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.seleniumEg\\src\\main\\resources\\LocateByLinkTextEg.html");
	    WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(35));
	    WebElement link1 = driver.findElement(By.linkText("Visit Expamle"));
	    link1.click();
	    
	    System.out.println("Title : "+driver.getTitle());
	    WebElement infolink =driver.findElement(By.partialLinkText("information"));
	    infolink.click();
	    Thread.sleep(3000);
	    
	    System.out.println("Next Page Title : "+driver.getTitle());
	    
	    
	    Thread.sleep(1000);
	    driver.quit();
}
}
