package com.seleniumEg;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByTagMultipleEg {
public static void main(String[] args) throws Exception {
	// chrome driver path
    System.setProperty("Webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win64");
    
    //Create the instance of driver
    WebDriver driver = new ChromeDriver();
    
    //Load the web page under test
    driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.seleniumEg\\src\\main\\resources\\LocateByNameEg.html");
    List <WebElement> elements =driver.findElements(By.tagName("input"));
    
    for(WebElement element : elements) {
    element.sendKeys("sone text here");
    System.out.println(element.getAttribute("name"));
    }
    Thread.sleep(2000);
    driver.quit();
    
}
}
