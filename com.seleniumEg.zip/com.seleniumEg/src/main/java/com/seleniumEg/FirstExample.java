package com.seleniumEg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FirstExample {

    public static void main(String[] args) throws Exception {

        // chrome driver path
        System.setProperty("Webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win64");
        
        // create an instance of WebDriver
        WebDriver driver = new ChromeDriver();
        
        
        // send get request for sample web page
         driver.get("http://www.example.com");
        

        // perform some operations on above loaded web page
         
         String title=driver.getTitle();
         System.out.println("Page title is:" +title);
         Thread.sleep(30000);
         driver.quit();
    }

}