package com.springbootDBexample.exception;

public class InvalidPlaceNameException extends RuntimeException{
	public InvalidPlaceNameException(String message) {
		super(message);
	}
}
