package com.springbootDBexample.repository;

import java.util.HashMap;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springbootDBexample.model.Ticket;


@Repository
public interface TicketRepository extends JpaRepository<Ticket,Integer>{


//	private HashMap<Integer, Ticket> tickets;
//
//	public TicketRepository() {
//		tickets = new HashMap<>();
//		tickets.put(1, new Ticket(1, "Place1312", "Place42342", 111));
//		tickets.put(2, new Ticket(2, "PlaceAAAA", "PlaceCCCC", 122));
//		tickets.put(3, new Ticket(3, "PlaceDDDD", "PlaceEEEE", 241));
//	}
//
//	Ticket getTicketRepo(int ticketid) {
//		Ticket ticket = tickets.get(ticketid);
//		return ticket;
//	}
//
//	Ticket bookTicketRepo(Ticket ticket) {
//		tickets.put(ticket.getId(), ticket);
//		return ticket;
//	}
//
//	Ticket updateTicketRepo(Ticket ticket) {
//		tickets.put(null, ticket);
//		return ticket;
//	}

}
