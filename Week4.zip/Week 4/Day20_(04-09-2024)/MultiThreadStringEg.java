package com.day20;

public class MultiThreadStringEg {
    public static void main(String[] args) {
        String str = "Now, I am developing multithreaded program";

        // Main thread
        System.out.println("Main Thread:");
        for (int i = 0; i < str.length(); i++) {
            System.out.print(str.charAt(i) + " ");
        }

        // Child thread
        Thread childThread = new Thread(() -> {
            System.out.println("\nChild Thread:");
            for (int i = 0; i < str.length(); i++) {
                System.out.print(str.charAt(i) + " ");
            }
        });

        childThread.start();
    }
}
