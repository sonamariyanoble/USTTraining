package com.day20;

//to print characters individually from a string using multi threading concept
class PrintCharss extends Thread {

	String string1 = "Sona";

	@Override
	public void run() {
		try {

			for (int i = 0; i < string1.length(); i++) {
				System.out.print(string1.charAt(i)+" ");

				Thread.sleep(30);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}

public class MultiThreadingStringEg2 {

	static String string1 = "Helloo";

	public static void main(String[] args) {

		try {

			PrintCharss thread = new PrintCharss();
			thread.start();
			for (int i = 0; i < string1.length(); i++) {
				System.out.print(string1.charAt(i)+" ");
				Thread.sleep(25);
			}

		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
