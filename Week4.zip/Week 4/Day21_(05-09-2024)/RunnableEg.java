package com.day21;


class ChildThread implements Runnable {
	@Override
	public void run(){
		for(int i=0; i<200;i+=3) {
			try {
			System.out.println("Child Thread : "+i);
			Thread.sleep(20);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}
}
public class RunnableEg  {
 public static void main(String[] args) throws Exception {
	 Thread t = new Thread(new ChildThread());
	 t.start();
	for(int j=0;j<400;j++) {
		System.out.println("Main Thread : "+j);
		Thread.sleep(20);
		
	}
}
}
