package com.jsoneg.day21;


import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import com.fasterxml.jackson.databind.ObjectMapper;

public class WriteJSONeg {
public static void main(String[] args) throws Exception {
	//Address objAdd = new Address("Street","City",669888);
	Address[] addrs = {
			new Address("Street1","City1",669888),
			new Address("Street2","City2",778877),
			new Address("Street3","City3",778877)
			};
	
     Person objPerson = new Person("Sona",27,addrs);
	/*obj.setName("Sona");
    obj.setAge(27);
    obj.setAddress(null);
    obj.setAddress("Street,Idukki,9876");*/
	
	ObjectMapper mapper = new ObjectMapper();
	FileOutputStream fos = new FileOutputStream("person.json");
	mapper.writeValue(fos, objPerson);
	System.out.println("File updated successfully with personal details");
	String pjson = mapper.writeValueAsString(objPerson);
	System.out.println("Created json file with content : "+pjson);
}
}
