package com.jsoneg.day21;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import com.fasterxml.jackson.databind.ObjectMapper;

public class ReadJSON {

	public static void main(String[] args) throws Exception {
		ObjectMapper omapper = new ObjectMapper();
		FileInputStream fis = new FileInputStream("person.json");
		
		Person obj =omapper.readValue(fis, Person.class);
		System.out.println(obj);
	}
}
