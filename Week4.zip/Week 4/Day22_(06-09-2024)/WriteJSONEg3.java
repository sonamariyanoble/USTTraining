package com.jsoneg.day22;

import com.fasterxml.jackson.core.exc.StreamWriteException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.FileOutputStream;
import java.io.IOException;

//When no POJO Class
public class WriteJSONEg3 {
public static void main(String[] args) throws Exception {
	ObjectMapper omapper = new ObjectMapper();
	
	ObjectNode onode = omapper.createObjectNode();
	onode.put("name", "Ravi");
	onode.put("age", 25);
	
	FileOutputStream fos = new FileOutputStream("./operson.json");
	omapper.writeValue(fos, onode);
	
	System.out.println("File got created....please check on the location");
	
}
}
