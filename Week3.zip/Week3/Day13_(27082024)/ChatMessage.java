package com.day13;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class ChatMessage {
	public static void main(String [] args) {
		HashMap<String,String> hmss=new HashMap<>();
		hmss.put("Sendername1", "message59");
		hmss.put("Sendername2", "message159");
		hmss.put("Sendername3", "message259");
		hmss.put("Sendername4", "message359");
		hmss.put("Sendername5", "message459");
		hmss.put("Sendername6", "message559");
		Set<String> ss=hmss.keySet();
		for(String item_key:ss) {
			//System.out.println(item_key+"--->"+hmss.get(item_key));
		}
		
		 TreeMap<String, String> tmss = new TreeMap<>(Comparator.reverseOrder());

	        // Adding entries to the TreeMap
	        tmss.put("Sendername1", "message59");
	        tmss.put("Sendername2", "message159");
	        tmss.put("Sendername3", "message259");
	        tmss.put("Sendername4", "message359");
	        tmss.put("Sendername5", "message459");
	        tmss.put("Sendername6", "message559");
	        System.out.println("\nPrinting using TreeMap\n");

	        // Iterating over the TreeMap and printing the entries
	        for (Map.Entry<String, String> entry : tmss.entrySet()) {
	            System.out.println(entry.getKey() + "--->" + entry.getValue());
	}

}
}