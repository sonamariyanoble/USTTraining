package com.day12;

enum Day {
	MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
};

public class EnumEg {

Day day = Day.MONDAY;

public static void main(String[] a) {

	Day today = Day.WEDNESDAY;
	printWeekend(today);
}

// an enum type can be used as local variable, parameter
static public void printWeekend(Day today) {
	if (today == Day.SATURDAY) {
		System.out.println("It's Weekend, Saturday");
	} else if (today == Day.SUNDAY) {
		System.out.println("It's Weekend, Sunday");
	} else {
		System.out.println("It's not Weekend");
	}
	switch(today) {
	case Day.MONDAY:
		System.out.println("Today is Monday");
		break;
	case Day.TUESDAY:
		System.out.println("Today is Tuesday");
		break;
	case Day.WEDNESDAY:
		System.out.println("Today is Wednesday");
		break;
		default:
			System.out.println("Today is not Monday,Tuesday,Wednesday");	
	}
}

//an enum type can be used as return type
Day getSunday() {
	return Day.SUNDAY;
}
}