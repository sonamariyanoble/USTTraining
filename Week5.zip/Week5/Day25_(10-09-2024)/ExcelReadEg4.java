package com.excelsample.day25;

import java.io.*;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReadEg4 {
	public static void main(String[] args) throws FileNotFoundException, IOException {
		// open file
		FileInputStream fis = new FileInputStream("./firstexcelNum.xlsx");

		// read workbook
		Workbook wbook = new XSSFWorkbook(fis);

		System.out.println("No. of sheets: " + wbook.getNumberOfSheets());

		int no_of_sheets = wbook.getNumberOfSheets();
		
		double value = 0;
		

		int no_of_rows = 0;
		Sheet st = null;
		
		
		for (int k = 0; k < no_of_sheets; k++) {
			// read sheet
			st = wbook.getSheetAt(k);

			no_of_rows = st.getPhysicalNumberOfRows();

			for (int i = 0; i < no_of_rows; i++) {
				// read rows
				Row row = st.getRow(i);

				int no_of_cols = row.getLastCellNum();

				for (int j = 0; j < no_of_cols; j++) {
					// read cells
					Cell cell = row.getCell(j);

					value = value + cell.getNumericCellValue();
				}
			}
		}
		System.out.println("sum is "+value);
		
		fis.close();
		

		FileOutputStream fos = new FileOutputStream("./firstexcelNum.xlsx");
		
		Row row = st.createRow(no_of_rows);
		System.out.println("Created row... "+(no_of_rows));
		Cell cell = row.createCell(0);
		cell.setCellValue(value);
		
		
		// Create a new sheet for the iteration count
        Sheet newSheet = wbook.createSheet("Iteration Count");
        Row newRow = newSheet.createRow(0);
        Cell newCell = newRow.createCell(0);
		
		//increment value by 1
		
		double values = newCell.getNumericCellValue()+1;
		newCell.setCellValue(values);

		
		
		fis.close();
		wbook.write(fos);
		 wbook.write(fos);
	        fos.close();

	}
}
