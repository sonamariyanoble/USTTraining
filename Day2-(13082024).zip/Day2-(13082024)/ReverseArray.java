package Assignment;

public class ReverseArray {
	public static void main(String []args) {
		int pincome[]=new int [5];
    	pincome [0]=31;
    	pincome [1]=21;
    	pincome [2]=11;
    	pincome [3]=41;
    	pincome [4]=15;
    	
    	for(int i=0;i<pincome.length;i++) {
    	System.out.println("Actual Array : "+pincome[i]);
    	}
    	
    	System.out.println("..................................");
    	
    	int[] rincome = reverseIncome(pincome);
    	for(int j=0;j<rincome.length ;j++) {
    	System.out.println("Reverse Array : "+ rincome[j]);
    			}
	}

	static int[] reverseIncome(int[] avalues) {
	  int n = avalues.length;
	  for(int i=0;i<n/2;i++) {
		  int temp=avalues[i];
		  avalues[i]=avalues[n-i-1];
		  avalues[n-i-1]=temp;
		  
	 }
		return avalues;
		
}
	
}

