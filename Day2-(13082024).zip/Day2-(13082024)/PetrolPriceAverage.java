package Assignment;

public class PetrolPriceAverage {
	public static void main(String[] args) {
		Double[] petrolPrices= {61.2,86.4,42.7,118.9,95.6,90.5};
		double sum=0;
		for(int i=0;i<petrolPrices.length;i++)
		{
			sum+=petrolPrices[i];
	
		}
		double averagePrice=sum/petrolPrices.length;
		System.out.println("The average of Petrol price is " +averagePrice);
	}


}
