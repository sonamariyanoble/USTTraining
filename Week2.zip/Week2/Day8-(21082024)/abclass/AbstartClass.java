package com.day8.abclass;


//It is not mandatory to have a abstract method in abstract class

abstract class PerCapitaIncome {
	void City() {
		
	}
}

public class AbstartClass {

}
