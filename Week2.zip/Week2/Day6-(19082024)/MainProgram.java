package com.day6.p7;

import com.day6.p5.PermanentEmployee;
import com.day6.p6.TemporaryEmployee;

public class MainProgram {

	public static void main(String[] args) {
		PermanentEmployee pobj = new PermanentEmployee(7, "Dhoni", 9876.6f, "mumabi address");
		pobj.displayp();
		TemporaryEmployee tobj = new TemporaryEmployee(32, "Ishan", 2344.09f, "delhi address");
		tobj.displayt();
	}

}
