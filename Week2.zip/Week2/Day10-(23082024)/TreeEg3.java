package com.day10;

import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

class Country{
	private String name;
	private double gdp;
	public Country(String name, double gdp) {
		super();
		this.name = name;
		this.gdp = gdp;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getGdp() {
		return gdp;
	}
	public void setGdp(double gdp) {
		this.gdp = gdp;
	}
	@Override
	public String toString() {
		return "Country [name=" + name + ", gdp=" + gdp + "]";
	}
	
	
}
//with comparator that is default order changed to descending order
public class TreeEg3 {
public static void main(String[] args) {
	
	//Anonymous inner class
	Comparator<Country> cc=new Comparator<Country>() {

		@Override
		public int compare(Country c1, Country c2) {
			return (int)(c1.getGdp()-c2.getGdp());
		}
		
	};
	TreeSet<Country> set = new TreeSet<Country>(cc);
	//adding vales to set
	
	set.add(new Country("USA",543.88));
	set.add(new Country("India",876.66));
	set.add(new Country("UK",765.99));
	set.add(new Country("China",675.44));
	
	Iterator<Country> itrs= set.iterator();
	
	for(;itrs.hasNext();) {
		System.out.println(itrs.next());
	}
	}
}




 