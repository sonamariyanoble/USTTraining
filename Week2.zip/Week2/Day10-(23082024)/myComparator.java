package com.day10;

import java.util.Comparator;

class myComparator implements Comparator<String>{

	@Override
	public int compare(String str1, String str2) {
		
		return str2.compareTo(str1); //decending order
		//return str1.compareTo(str2); ///asending order ---- without comparator class also it is in ascending order as default order.
	}
	
}
