package com.day10;

import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

//without comparator, i.e with default order(ascending)
public class TreeSetEg {
public static void main(String[] args) {
	TreeSet<String> tss = new TreeSet<String>();
	//adding vales to set
	
	tss.add("Apple");
	tss.add("Orange");
	tss.add("Young");
	tss.add("Avacado");
	
	Iterator<String> itrs= tss.iterator();
	
	for(;itrs.hasNext();) {
		System.out.println(itrs.next());
	}
	}
}


 