package com.day10;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;


class City{
	private String name;
	private long pincode;
	private String state;
	
	//constructor
	public City(String name, long pincode, String state) {
		this.name = name;
		this.pincode = pincode;
		this.state = state;
	}
	
	//getter, setter - TBD
	
	//toString
	@Override
	public String toString() {
		return "City [name=" + name + ", pincode=" + pincode + ", state=" + state + "]";
	}
}

public class ListEg {
public static void main (String[]arags) {
	//create list
	
	//List cities = new ArrayList();  // using object
	List <City> cities = new ArrayList <City>(); //using generic
	Scanner scan = new Scanner(System.in);
	//add city objects to list
	
    cities.add(new City ("city1",1234,"state1"));
    cities.add(new City ("city2",3456,"state2"));
    cities.add(new City ("city3",5678,"state3"));
    
    System.out.print("Please enter name of city");
    String icity = scan.next();
    scan.nextLine();
    
    System.out.print("Please enter the pincode");
    long ipincode = scan.nextLong();
    scan.nextLine();
    
    System.out.print("Please enter the name of state");
    String istate = scan.next();
    scan.nextLine();
    
    cities.add(new City (icity,ipincode,istate));
    System.out.println("City : "+icity);
    System.out.println("Pincode : "+ipincode);
    System.out.println("State : "+istate);
    
    scan.close();
    //iterate and display
    
    //Iterator itr = cities.iterator();      //using object
    Iterator <City> itr = cities.iterator(); //using generic
    
    while(itr.hasNext()) {
    	System.out.println(itr.next());
    }
	
}
}
