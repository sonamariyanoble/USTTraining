package com.day7;

public class OverridingEg {
	public static void main(String[] args) {

		Product obj = new ElectronicProduct();
		// method overriding or dynamic polymorphism (runtime decision)
		obj.display(); // display of derived
		obj = new Product(12,"Testing");
		

		obj.display(); // display of base class
		System.out.println("Product Object is " + obj.toString());
	}
}

class Product {

	private int id;
	private String name;

	public Product() {

	}

	public Product(int id, String name) {
		this.id = id;
		this.name = name;

	}

	public void display() {
		System.out.println("Product.display()");
	}

	public String toString() {
		return "'id= " + id + " name= " + name + "'";
	}
	
	/*
	 * public final void notify() {
	 * 
	 * }
	 */
}

//Inheritance is Is-A-Relationship
class ElectronicProduct extends Product {
	
	public ElectronicProduct()
	{
		
	}
	public ElectronicProduct(int id, String name) {
		super(id, name);
		

	}

	private float voltage;

	public void display() {
		System.out.println("ElectronicProduct.display()");
	}

}