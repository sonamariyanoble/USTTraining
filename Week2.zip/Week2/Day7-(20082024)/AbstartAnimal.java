package com.day7;

abstract class AnimalClass{
	int legs;
	String name;
	abstract void move();
	
	AnimalClass(String name, int legs){
		//super();
		this.legs=legs;
		this.name=name;		
	}
	
	public void animaldetails() {
		System.out.println("Animal name is " +name + " and have " +legs + " legs");
	}
}
//Concrete class (non-abstract class)
class Snake extends AnimalClass{

	Snake(String name, int legs) {
		super(name, legs);
	}

	void move() {
		System.out.println("Crawling.....");
	}
	
}

public class AbstartAnimal {
	public static void main(String[] args) {
		AnimalClass obj = new Snake("Lion", 4);
			obj.animaldetails();
	} 
}
