package com.day9.p1;

import java.util.*;

class City{
	private String name;
	private long pincode;
	private String state;
	
	//constructor
	public City(String name, long pincode, String capital_city) {
		this.name = name;
		this.pincode = pincode;
		this.state = capital_city;
	}
	
	//getter, setter - TBD
	
	//toString
	@Override
	public String toString() {
		return "City [name=" + name + ", pincode=" + pincode + ", state=" + state + "]";
	}
}

public class LearningEgClass {
public static void main(String[] args) {
	//create List
	List<City> cities = new ArrayList<City>();
	Scanner scnr = new Scanner(System.in);
	
	//add City objects to List
	cities.add(new City("city1", 1234, "capital1"));
	cities.add(new City("city2", 3456, "capital2"));
	
//	System.out.println("Please enter city name");
//	String icity = scnr.next();
//	
//	System.out.println("Please enter pincode");
//	long ipincode = scnr.nextLong();
//	
//	System.out.println("Please enter State name");
//	String istate = scnr.next();
	
//	cities.add(new City(icity, ipincode, istate));
	
	//iterate and display
	Iterator<City> itr = cities.iterator();
	
	while(itr.hasNext()){
		System.out.println(itr.next());
	}
	
	
}
}
